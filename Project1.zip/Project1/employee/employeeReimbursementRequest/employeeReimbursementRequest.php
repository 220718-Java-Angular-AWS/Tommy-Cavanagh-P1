<?php
/*
MIT License
Copyright (c) 2019 Fernando 
https://github.com/fernandod1/
*/

// Configure your mysql database connection details:

$mysqlserverhost = "localhost";
$database_name = "krxugfqu_project1";
$username_mysql = "krxugfqu_tommy";
$password_mysql = "CodelyokO8888";

// ------------------------- Do not modify code under this field -------------------------- //


function sanitize($variable){
	$clean_variable = strip_tags($variable);
	$clean_variable = htmlentities($clean_variable, ENT_QUOTES, 'UTF-8');
	return $clean_variable;
}

function connect_to_mysqli($mysqlserverhost, $username_mysql, $password_mysql, $database_name){
	$connect = mysqli_connect($mysqlserverhost, $username_mysql, $password_mysql, $database_name);
	if (!$connect) {
		  die("Connection failed mysql: " . mysqli_connect_error());
	}
	return $connect;	
}

if(isset($_POST["processform"])){
	$connection = connect_to_mysqli($mysqlserverhost, $username_mysql, $password_mysql, $database_name);
	$fullName = mysqli_real_escape_string($connection, sanitize($_POST["fullName"]));
	$empCode = mysqli_real_escape_string($connection, sanitize($_POST["empCode"]));
	$salary = mysqli_real_escape_string($connection, sanitize($_POST["salary"]));
	$city = mysqli_real_escape_string($connection, sanitize($_POST["city"]));
	$purpose = mysqli_real_escape_string($connection, sanitize($_POST["purpose"]));
	$sql = "INSERT INTO `reimbursementTest` (fullName, empCode, salary, city, purpose) VALUES ('$fullName', '$empCode', '$salary', '$city', '$purpose')";
	if (mysqli_query($connection, $sql)) {
		  echo "<h2><font color=#293241>New record added to database.</font></h2>";
	} else {
		  echo "Error: " . $sql . "<br>" . mysqli_error($connection);
	}
	mysqli_close($connection);
}

?>

<!DOCTYPE html>
<html>



<head>
    <title>
       Revature Project 1
    </title>
    <link rel="stylesheet" href="styles.css">
    
    <style>
body {font-family: Arial, Helvetica, sans-serif; background-color: #98c1d9;}
form {border: 1px solid #f1f1f1; background: #293241; color: #98c1d9;}

input[type=text], input[type=password], input[type=number] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #98c1d9;
  color: #293241;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #98c1d9;
  color: #293241;
}

.container {
  padding: 16px;
  background: #293241;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
.button5 {border-radius: 50%;
    width: 10%;
    float: right;
    color: #e0fbfc;
    margin: 10px;
}

/* two columns css*/ 

* {
  box-sizing: border-box;
}

/* Create two equal columns that floats next to each other */
.column {
  float: left;
  width: 50%;
  padding: 10px;
  height: 300px; /* Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Table CSS*/ 
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #98c1d9;
}

tr:nth-child(odd) {
  background-color: #293241;
}

/* Signature submit */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap');


.flex-row {
    display: flex;
}
.wrapper {
    border: 1px solid #4b00ff;
    border-right: 0;
}

button#clear {
    height: 100%;
    background: #4b00ff;
    border: 1px solid transparent;
    color: #fff;
    font-weight: 600;
    cursor: pointer;
}
button#clear span {
    transform: rotate(90deg);
    display: block;
}

body > table{
    width: 80%;
}

table{
    border-collapse: collapse;
}
table.list{
    width:100%;
}

td, th {
    border: 1px solid #dddddd;
    color: #98c1d9;
    background: #293241;
    text-align: left;
    padding: 8px;
}
tr:nth-child(even),table.list thead>tr {
    background-color: #dddddd;
}

input[type=text], input[type=number] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type=submit]{
    width: 30%;
    background-color: #ddd;
    color: #000;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

form div.form-action-buttons{
    text-align: right;
}

a{
    cursor: pointer;
    text-decoration: underline;
    color: #0000ee;
    margin-right: 4px;
}

label.validation-error{
    color:   red;
    margin-left: 5px;
}

.hide{
    display:none;
}

#purpose{
    width: 200px;
    height: 40px;
}

</style>
</head>
<script type="text/javascript">
  function validateForm() {
    var a = document.forms["Form"]["fullName"].value;
    var b = document.forms["Form"]["empCode"].value;
    var c = document.forms["Form"]["salary"].value;
     var d = document.forms["Form"]["city"].value;
      var e = document.forms["Form"]["purpose"].value;
    if (a == null || a == "", b == null || b == "", c == null || c == "", d == null || d == "", e == null || e == "") {
      alert("Please Fill All Required Field");
      return false;
    }
  }
</script>

<body>

<button class="button button5"><a href="https://thomascavanagh.com/RevatureProjects/Project1/index.html" style="{border-radius: 50%;}">Home</a></button>

    <table>
        <tr>
            <td>
                <form method="POST" name="Form" onsubmit="event.preventDefault();onFormSubmit();" autocomplete="off">
                    <h1>Expense Reimbursement Form</h1>
                    <div>
                        <label><b>Employee Name*</b></label><label class="validation-error hide" id="fullNameValidationError">This field is required.</label>
                        <input type="text" placeholder="Enter ID" name="fullName" id="fullName">
                    </div>
                    <div>
                        <label><b>Manager</b></label>
                        <input type="text" placeholder="Enter Manager" name="empCode" id="empCode">
                    </div>
                    <div>
                        <label><b>ID</b></label>
                        <input type="text" placeholder="Enter ID" name="salary" id="salary">
                    </div>
                    <div>
                        <label><b>Department</b></label>
                        <input type="text" placeholder="Enter Department" name="city" id="city">
                    </div>
                    <div>
                        <label><b>Buisness Purpose</b></label><br>
                        <select id="purpose">
                            <option disabled selected value>Select your purpose </option>
  <option value="lodging">Lodging</option>
  <option value="food">Food</option>
  <option value="travel">Travel</option>
</select>
                        
                    </div>
                    <div  class="form-action-buttons">
                        <input type="submit" value="Submit">
                    </div>
                </form>
            </td>
            <td>
                <table class="list" id="employeeList">
                    <thead>
                        <tr>
                            <th>Employee Name</th>
                            <th>Manager</th>
                            <th>ID</th>
                            <th>Department</th>
                            <th>Purpose</th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </td>
        </tr>
    </table>
    <script src="script.js"></script>
</body>

</html>